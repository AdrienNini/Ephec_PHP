[ERREUR]
interdit = "<?php die('vous n\'êtes pas autorisé à voir ce contenu'); ?>"

[SITE]
titre = "SITEX : Phase 04 - Adaptation des menus"
images = "IMG"

[LOGO]
logo = "04.png"
taille = "200"
min = "150"
max = "250"
pas = "10"

[DB]
host = "localhost"
user = "NINIPEREIRA"
pswd = "Adrieng2Y9"
dbname = "1718he201440"

[AVATAR]
comment = "le dossier devra se trouver dans celui des images du SITE"
dossier = "avatar"
anonyme = "unknow.png"
min = "100"
taille = "150"
max = "200"
type = "jpg|gif|png"
choix[] = "jpg"
choix[] = "png"

[EPHEC]
admin = "znini3638"
