<?php  
if ( count( get_included_files() ) == 1) die( '--access denied--' );

define('___MATRICULE___','HE201440');

if(stripos($_SERVER['PHP_SELF'],___MATRICULE___)==FALSE) {
	trigger_error("TENTATIVE DE FRAUDE de {$_SERVER['PHP_SELF']} chez ".___MATRICULE___, E_USER_ERROR);
	exit;
} 
else{
	$__INFOS__ = array(   'matricule'=> ___MATRICULE___
					,'host' => 'localhost'
					,'user' => 'NINIPEREIRA'
					,'pswd' => 'Adrieng2Y9'
					,'dbName' => '1718he201440'
					,'nom' => 'NINIPEREIRA'
					,'prenom' => 'Adrien'  
					,'classe' => '2TL1'  
					);
}

$sess_name = md5('he201440fshdiujfbesinldchkxj');